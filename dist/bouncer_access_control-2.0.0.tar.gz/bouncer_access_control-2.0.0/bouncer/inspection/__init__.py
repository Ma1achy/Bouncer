"""
Inspection module exports
"""
from .stack_inspector import StackInspector

__all__ = ['StackInspector']
